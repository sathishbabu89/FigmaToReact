import React from 'react';
import LoginForm from '../components/LoginForm';

const LoginPage = () => {
  return (
    <div className="sm:mx-auto sm:w-full sm:max-w-md">
      <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">Simple Login Page</h2>
        </div>
        <LoginForm />
      </div>
    </div>
  );
};

export default LoginPage;